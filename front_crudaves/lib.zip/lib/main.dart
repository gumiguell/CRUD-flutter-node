import 'package:flutter/material.dart';
import 'package:crud_api/screen/post.dart';
import 'package:crud_api/screen/get.dart';

void main() => runApp(const MaterialApp(
    debugShowCheckedModeBanner: false, title: "APP CRUD", home: MainApp()));

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          centerTitle: true,
          title: const Text("API CRUD"),
          backgroundColor: const Color.fromARGB(255, 74, 159, 188)),
      drawer: Drawer(
          child: ListView(
          padding: EdgeInsets.zero,
          children: [
          const DrawerHeader(
              decoration: BoxDecoration(color: Color.fromARGB(255, 52, 132, 197)),                          
              child: Text("Products",style: TextStyle(fontSize: 30,color: Colors.white))
          ),
          ListTile(
              leading: const Icon(Icons.home),
              title: const Text("Home"),
              onTap: () {
                Navigator.pop(context);
              }),
          ListTile(
              leading: const Icon(Icons.shopping_bag),
              title: const Text("Get"),
              onTap: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) {
                      return const GET();
                    },
                  ),
                );
              }),
          ListTile(
              leading: const Icon(Icons.add),
              title: const Text("Post"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) {
                      return const POST();
                    },
                  ),
                );
              }),
        ],
      )),
      body: const Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.start, 
        children: [
        ])),
    );
  }
}
