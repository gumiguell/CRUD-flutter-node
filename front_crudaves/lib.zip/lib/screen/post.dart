import 'package:flutter/material.dart';
import 'package:crud_api/service/http.dart';

class POST extends StatefulWidget {
  const POST({super.key});

  @override
  State<StatefulWidget> createState() => _POSTState();
}

class _POSTState extends State<POST> {
  TextEditingController name = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController desc = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(10),
         child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(10),
              child:TextField(              
                controller: name,
                decoration: const InputDecoration(label:Text("Product name")),
              )   
            ),
            Padding(
              padding: EdgeInsets.all(10),
              child:TextField(              
                controller: price,
                decoration: InputDecoration(label:Text("Product price")),
              )
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child:TextField(              
                controller: desc,
                decoration: const InputDecoration(label:Text("Product desc")),
              )   
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child:ElevatedButton(              
                onPressed: () {
                  var data = {
                    "name":  name.text,
                    "price": price.text,
                    "desc": desc.text
                  };
                  Http.postProduct(data);                  
                },
                child: const Text("POST")                
              )   
            )   
          ]
         ),
      )
    );
  }
}
