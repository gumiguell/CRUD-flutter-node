//library de conversão json
import 'dart:convert';
//library http importada no pubspec.yaml
import 'package:http/http.dart' as http;
//classe abstração de produto
import 'package:crud_api/model/product_model.dart';

class Http {
  static String url = "http://177.220.18.43/api/";

  static getProduct() async {
    List<Product> product = [];
    try {
      final res = await http.get(Uri.parse("${url}get_product"));
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        data['product'].forEach((value) => {
              product.add(Product(value['name'], value['price'], value['desc']))
            });
        return product;
      }
    } catch (e) {
      print(e.toString());
    }
  }

  static postProduct(Map pdata) async {
    try {
      final res = await http.post(Uri.parse("${url}add_product"), body: pdata);
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body.toString());
        print(data);
      } else {
          print("Failed to load data");
      }
    } catch (e) {
        print(e.toString());
    }
  }
}
